﻿namespace NakaharaPDV.CONEXION
{
    class CONEXIONMAESTRA
    {
        public static string conexion = "server=localhost;user id=nakaharacompany;password=nakaharadb123;persistsecurityinfo=True;database=nakaharadb";
    }
}
