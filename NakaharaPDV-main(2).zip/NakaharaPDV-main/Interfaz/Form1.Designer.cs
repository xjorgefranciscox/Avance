﻿namespace NakaharaPDV
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelMenu = new System.Windows.Forms.Panel();
            this.panelLogo = new System.Windows.Forms.Panel();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.ventasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.clientesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.iconBtnCorte = new FontAwesome.Sharp.IconButton();
            this.iconBtnConfig = new FontAwesome.Sharp.IconButton();
            this.iconBtnInventario = new FontAwesome.Sharp.IconButton();
            this.iconBtnProductos = new FontAwesome.Sharp.IconButton();
            this.iconBtnClientes = new FontAwesome.Sharp.IconButton();
            this.iconBtnVentas = new FontAwesome.Sharp.IconButton();
            this.panelTituloBar = new System.Windows.Forms.Panel();
            this.IconoHijo = new FontAwesome.Sharp.IconPictureBox();
            this.lblTituloHijo = new System.Windows.Forms.Label();
            this.panelDesktop = new System.Windows.Forms.Panel();
            this.panelMenu.SuspendLayout();
            this.panelLogo.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.panelTituloBar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.IconoHijo)).BeginInit();
            this.SuspendLayout();
            // 
            // panelMenu
            // 
            this.panelMenu.BackColor = System.Drawing.Color.White;
            this.panelMenu.Controls.Add(this.panelLogo);
            this.panelMenu.Controls.Add(this.iconBtnCorte);
            this.panelMenu.Controls.Add(this.iconBtnConfig);
            this.panelMenu.Controls.Add(this.iconBtnInventario);
            this.panelMenu.Controls.Add(this.iconBtnProductos);
            this.panelMenu.Controls.Add(this.iconBtnClientes);
            this.panelMenu.Controls.Add(this.iconBtnVentas);
            this.panelMenu.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelMenu.Location = new System.Drawing.Point(0, 0);
            this.panelMenu.Name = "panelMenu";
            this.panelMenu.Size = new System.Drawing.Size(1067, 158);
            this.panelMenu.TabIndex = 0;
            this.panelMenu.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // panelLogo
            // 
            this.panelLogo.Controls.Add(this.menuStrip1);
            this.panelLogo.Location = new System.Drawing.Point(0, 0);
            this.panelLogo.Name = "panelLogo";
            this.panelLogo.Size = new System.Drawing.Size(1064, 100);
            this.panelLogo.TabIndex = 7;
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ventasToolStripMenuItem,
            this.clientesToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1064, 30);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // ventasToolStripMenuItem
            // 
            this.ventasToolStripMenuItem.Name = "ventasToolStripMenuItem";
            this.ventasToolStripMenuItem.Size = new System.Drawing.Size(66, 24);
            this.ventasToolStripMenuItem.Text = "Ventas";
            // 
            // clientesToolStripMenuItem
            // 
            this.clientesToolStripMenuItem.Name = "clientesToolStripMenuItem";
            this.clientesToolStripMenuItem.Size = new System.Drawing.Size(75, 24);
            this.clientesToolStripMenuItem.Text = "Clientes";
            // 
            // iconBtnCorte
            // 
            this.iconBtnCorte.BackColor = System.Drawing.Color.White;
            this.iconBtnCorte.FlatAppearance.BorderSize = 0;
            this.iconBtnCorte.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconBtnCorte.IconChar = FontAwesome.Sharp.IconChar.CashRegister;
            this.iconBtnCorte.IconColor = System.Drawing.Color.Black;
            this.iconBtnCorte.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconBtnCorte.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconBtnCorte.Location = new System.Drawing.Point(917, 103);
            this.iconBtnCorte.Name = "iconBtnCorte";
            this.iconBtnCorte.Padding = new System.Windows.Forms.Padding(10, 0, 20, 0);
            this.iconBtnCorte.Size = new System.Drawing.Size(147, 49);
            this.iconBtnCorte.TabIndex = 6;
            this.iconBtnCorte.Text = "Corte";
            this.iconBtnCorte.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconBtnCorte.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.iconBtnCorte.UseVisualStyleBackColor = false;
            this.iconBtnCorte.Click += new System.EventHandler(this.iconBtnCorte_Click);
            // 
            // iconBtnConfig
            // 
            this.iconBtnConfig.BackColor = System.Drawing.Color.White;
            this.iconBtnConfig.FlatAppearance.BorderSize = 0;
            this.iconBtnConfig.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconBtnConfig.IconChar = FontAwesome.Sharp.IconChar.Cogs;
            this.iconBtnConfig.IconColor = System.Drawing.Color.Black;
            this.iconBtnConfig.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconBtnConfig.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconBtnConfig.Location = new System.Drawing.Point(736, 103);
            this.iconBtnConfig.Name = "iconBtnConfig";
            this.iconBtnConfig.Padding = new System.Windows.Forms.Padding(10, 0, 20, 0);
            this.iconBtnConfig.Size = new System.Drawing.Size(175, 49);
            this.iconBtnConfig.TabIndex = 5;
            this.iconBtnConfig.Text = "Configuraciones";
            this.iconBtnConfig.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconBtnConfig.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.iconBtnConfig.UseVisualStyleBackColor = false;
            this.iconBtnConfig.Click += new System.EventHandler(this.iconBtnConfig_Click);
            // 
            // iconBtnInventario
            // 
            this.iconBtnInventario.BackColor = System.Drawing.Color.White;
            this.iconBtnInventario.FlatAppearance.BorderSize = 0;
            this.iconBtnInventario.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconBtnInventario.IconChar = FontAwesome.Sharp.IconChar.Boxes;
            this.iconBtnInventario.IconColor = System.Drawing.Color.Black;
            this.iconBtnInventario.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconBtnInventario.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconBtnInventario.Location = new System.Drawing.Point(555, 103);
            this.iconBtnInventario.Name = "iconBtnInventario";
            this.iconBtnInventario.Padding = new System.Windows.Forms.Padding(10, 0, 20, 0);
            this.iconBtnInventario.Size = new System.Drawing.Size(175, 49);
            this.iconBtnInventario.TabIndex = 4;
            this.iconBtnInventario.Text = "Inventario";
            this.iconBtnInventario.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconBtnInventario.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.iconBtnInventario.UseVisualStyleBackColor = false;
            this.iconBtnInventario.Click += new System.EventHandler(this.iconBtnInventario_Click);
            // 
            // iconBtnProductos
            // 
            this.iconBtnProductos.BackColor = System.Drawing.Color.White;
            this.iconBtnProductos.FlatAppearance.BorderSize = 0;
            this.iconBtnProductos.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconBtnProductos.IconChar = FontAwesome.Sharp.IconChar.HandHoldingUsd;
            this.iconBtnProductos.IconColor = System.Drawing.Color.Black;
            this.iconBtnProductos.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconBtnProductos.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconBtnProductos.Location = new System.Drawing.Point(374, 103);
            this.iconBtnProductos.Name = "iconBtnProductos";
            this.iconBtnProductos.Padding = new System.Windows.Forms.Padding(10, 0, 20, 0);
            this.iconBtnProductos.Size = new System.Drawing.Size(175, 49);
            this.iconBtnProductos.TabIndex = 3;
            this.iconBtnProductos.Text = "Productos";
            this.iconBtnProductos.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconBtnProductos.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.iconBtnProductos.UseVisualStyleBackColor = false;
            this.iconBtnProductos.Click += new System.EventHandler(this.iconBtnProductos_Click);
            // 
            // iconBtnClientes
            // 
            this.iconBtnClientes.BackColor = System.Drawing.Color.White;
            this.iconBtnClientes.FlatAppearance.BorderSize = 0;
            this.iconBtnClientes.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconBtnClientes.IconChar = FontAwesome.Sharp.IconChar.Male;
            this.iconBtnClientes.IconColor = System.Drawing.Color.Black;
            this.iconBtnClientes.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconBtnClientes.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconBtnClientes.Location = new System.Drawing.Point(193, 103);
            this.iconBtnClientes.Name = "iconBtnClientes";
            this.iconBtnClientes.Padding = new System.Windows.Forms.Padding(10, 0, 20, 0);
            this.iconBtnClientes.Size = new System.Drawing.Size(175, 49);
            this.iconBtnClientes.TabIndex = 2;
            this.iconBtnClientes.Text = "Clientes";
            this.iconBtnClientes.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconBtnClientes.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.iconBtnClientes.UseVisualStyleBackColor = false;
            this.iconBtnClientes.Click += new System.EventHandler(this.iconBtnClientes_Click);
            // 
            // iconBtnVentas
            // 
            this.iconBtnVentas.BackColor = System.Drawing.Color.White;
            this.iconBtnVentas.FlatAppearance.BorderSize = 0;
            this.iconBtnVentas.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.iconBtnVentas.ForeColor = System.Drawing.Color.Black;
            this.iconBtnVentas.IconChar = FontAwesome.Sharp.IconChar.MoneyBillWave;
            this.iconBtnVentas.IconColor = System.Drawing.Color.Black;
            this.iconBtnVentas.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.iconBtnVentas.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconBtnVentas.Location = new System.Drawing.Point(12, 103);
            this.iconBtnVentas.Name = "iconBtnVentas";
            this.iconBtnVentas.Padding = new System.Windows.Forms.Padding(10, 0, 20, 0);
            this.iconBtnVentas.Size = new System.Drawing.Size(175, 49);
            this.iconBtnVentas.TabIndex = 1;
            this.iconBtnVentas.Text = "Ventas";
            this.iconBtnVentas.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.iconBtnVentas.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.iconBtnVentas.UseVisualStyleBackColor = false;
            this.iconBtnVentas.Click += new System.EventHandler(this.iconBtnVentas_Click);
            // 
            // panelTituloBar
            // 
            this.panelTituloBar.Controls.Add(this.IconoHijo);
            this.panelTituloBar.Controls.Add(this.lblTituloHijo);
            this.panelTituloBar.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTituloBar.Location = new System.Drawing.Point(0, 158);
            this.panelTituloBar.Name = "panelTituloBar";
            this.panelTituloBar.Size = new System.Drawing.Size(1067, 36);
            this.panelTituloBar.TabIndex = 1;
            // 
            // IconoHijo
            // 
            this.IconoHijo.BackColor = System.Drawing.SystemColors.Control;
            this.IconoHijo.ForeColor = System.Drawing.SystemColors.ControlText;
            this.IconoHijo.IconChar = FontAwesome.Sharp.IconChar.Home;
            this.IconoHijo.IconColor = System.Drawing.SystemColors.ControlText;
            this.IconoHijo.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.IconoHijo.Location = new System.Drawing.Point(3, 3);
            this.IconoHijo.Name = "IconoHijo";
            this.IconoHijo.Size = new System.Drawing.Size(32, 32);
            this.IconoHijo.TabIndex = 2;
            this.IconoHijo.TabStop = false;
            this.IconoHijo.Click += new System.EventHandler(this.iconPictureBox1_Click);
            // 
            // lblTituloHijo
            // 
            this.lblTituloHijo.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTituloHijo.Location = new System.Drawing.Point(38, 3);
            this.lblTituloHijo.Name = "lblTituloHijo";
            this.lblTituloHijo.Size = new System.Drawing.Size(95, 29);
            this.lblTituloHijo.TabIndex = 1;
            this.lblTituloHijo.Text = "Home";
            // 
            // panelDesktop
            // 
            this.panelDesktop.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panelDesktop.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panelDesktop.Location = new System.Drawing.Point(0, 193);
            this.panelDesktop.Name = "panelDesktop";
            this.panelDesktop.Size = new System.Drawing.Size(1067, 563);
            this.panelDesktop.TabIndex = 2;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1067, 756);
            this.Controls.Add(this.panelTituloBar);
            this.Controls.Add(this.panelDesktop);
            this.Controls.Add(this.panelMenu);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Form1_MouseDown);
            this.panelMenu.ResumeLayout(false);
            this.panelLogo.ResumeLayout(false);
            this.panelLogo.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.panelTituloBar.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.IconoHijo)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelMenu;
        private FontAwesome.Sharp.IconButton iconBtnVentas;
        private FontAwesome.Sharp.IconButton iconBtnCorte;
        private FontAwesome.Sharp.IconButton iconBtnConfig;
        private FontAwesome.Sharp.IconButton iconBtnInventario;
        private FontAwesome.Sharp.IconButton iconBtnProductos;
        private FontAwesome.Sharp.IconButton iconBtnClientes;
        private System.Windows.Forms.Panel panelTituloBar;
        private System.Windows.Forms.Label lblTituloHijo;
        private FontAwesome.Sharp.IconPictureBox IconoHijo;
        private System.Windows.Forms.Panel panelLogo;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem ventasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem clientesToolStripMenuItem;
        private System.Windows.Forms.Panel panelDesktop;
    }
}

