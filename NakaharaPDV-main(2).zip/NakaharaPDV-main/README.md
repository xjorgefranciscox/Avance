# NakaharaPDV
Punto de venta Nakahara

Integrantes:
-Francisco Uriel Marin Macias
-Lorena Beatriz Zamarripa de León
-Carlos Adonai de la Cruz Ortiz
-Jorge Francisco Villanueva Laina
