﻿using System;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.IO;

namespace NakaharaPDV.Modulos
{
    public partial class Usuarios : Form
    {
        public Usuarios()
        {
            InitializeComponent();
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            if (txtNombre.Text != "")
            {
                try
                {
                    MySqlConnection con = new MySqlConnection();
                    con.ConnectionString = CONEXION.CONEXIONMAESTRA.conexion;
                    con.Open();
                    MySqlCommand cmd = new MySqlCommand();
                    cmd = new MySqlCommand("Insertar_Usuario", con);
                    cmd.Parameters.AddWithValue("aNombres", txtNombre.Text);
                    cmd.Parameters.AddWithValue("aLogin", txtUsuario.Text);
                    cmd.Parameters.AddWithValue("aPassword", txtPassword.Text);
                    cmd.Parameters.AddWithValue("aCorreo", txtCorreo.Text);
                    cmd.Parameters.AddWithValue("aRol", txtRol.Text);

                    MemoryStream ms = new MemoryStream();
                    ICONO.Image.Save(ms, ICONO.Image.RawFormat);
                    cmd.Parameters.AddWithValue("aIcono", ms.GetBuffer());
                    cmd.Parameters.AddWithValue("aNombre_de_Icono", lblNumeroIcono.Text);
                    cmd.ExecuteNonQuery();
                    con.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            ICONO.Image = pictureBox3.Image;
            lblNumeroIcono.Text = "1";
            lblAnuncioIcono.Visible = false;
            panelICONO.Visible = false;
        }

        private void lblAnuncioIcono_Click(object sender, EventArgs e)
        {
            panelICONO.Visible = true;
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            ICONO.Image = pictureBox4.Image;
            lblNumeroIcono.Text = "2";
            lblAnuncioIcono.Visible = false;
            panelICONO.Visible = false;
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            ICONO.Image = pictureBox5.Image;
            lblNumeroIcono.Text = "3";
            lblAnuncioIcono.Visible = false;
            panelICONO.Visible = false;
        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            ICONO.Image = pictureBox6.Image;
            lblNumeroIcono.Text = "4";
            lblAnuncioIcono.Visible = false;
            panelICONO.Visible = false;
        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {
            ICONO.Image = pictureBox7.Image;
            lblNumeroIcono.Text = "5";
            lblAnuncioIcono.Visible = false;
            panelICONO.Visible = false;
        }

        private void pictureBox8_Click(object sender, EventArgs e)
        {
            ICONO.Image = pictureBox8.Image;
            lblNumeroIcono.Text = "6";
            lblAnuncioIcono.Visible = false;
            panelICONO.Visible = false;
        }

        private void pictureBox9_Click(object sender, EventArgs e)
        {
            ICONO.Image = pictureBox9.Image;
            lblNumeroIcono.Text = "7";
            lblAnuncioIcono.Visible = false;
            panelICONO.Visible = false;
        }

        private void pictureBox10_Click(object sender, EventArgs e)
        {
            ICONO.Image = pictureBox10.Image;
            lblNumeroIcono.Text = "8";
            lblAnuncioIcono.Visible = false;
            panelICONO.Visible = false;
        }

        private void Usuarios_Load(object sender, EventArgs e)
        {
            panel4.Visible = false;
        }

        private void AgregarUsuario_Click(object sender, EventArgs e)
        {
            panel4.Visible = true;
        }

        private void btnCerrar_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
